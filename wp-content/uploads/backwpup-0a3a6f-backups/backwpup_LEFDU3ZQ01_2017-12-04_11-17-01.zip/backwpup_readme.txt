Wellicht heb je het manifest.json bestand in dit archief opgemerkt.
manifest.json zou nodig kunnen zijn om later een back-up te kunnen herstellen uit dit archief.
Laat manifest.json waar het staat en bewerk het niet. Zo is het veilig om genegeerd te worden.
